package by.vstu.vsrpp.exam.studgroup.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    /**
     * Настройка пользователей в памяти (in-memory) с ролями:
     *   STUDENT  — просмотр данных о студентах (GET /api/student/**)
     *   TEACHER  — просмотр данных о группах   (GET /api/group/**)
     *   ADMIN    — полный доступ ко всему
     */
    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth.inMemoryAuthentication()
            .withUser("student")
                .password(passwordEncoder().encode("student123"))
                .roles("STUDENT")
            .and()
            .withUser("teacher")
                .password(passwordEncoder().encode("teacher123"))
                .roles("TEACHER")
            .and()
            .withUser("admin")
                .password(passwordEncoder().encode("admin123"))
                .roles("ADMIN");
    }

    /**
     * Правила разграничения доступа:
     *   STUDENT  → GET /api/student/**
     *   TEACHER  → GET /api/group/**
     *   ADMIN    → все эндпоинты (любой HTTP-метод)
     */
    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http
            .csrf().disable()
            .authorizeRequests()
                // STUDENT — только чтение студентов
                .antMatchers(HttpMethod.GET, "/api/student/**").hasAnyRole("STUDENT", "ADMIN")
                // TEACHER — только чтение групп
                .antMatchers(HttpMethod.GET, "/api/group/**").hasAnyRole("TEACHER", "ADMIN")
                // Всё остальное — только ADMIN
                .anyRequest().hasRole("ADMIN")
            .and()
            .httpBasic();  // базовая HTTP-аутентификация (логин:пароль в заголовке)
    }
}
